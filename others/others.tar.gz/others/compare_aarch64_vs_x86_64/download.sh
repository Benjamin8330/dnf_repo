wget https://rpmfind.net/linux/almalinux/8/isos/aarch64/AlmaLinux-8.10-aarch64-dvd.iso
wget https://rpmfind.net/linux/almalinux/8/isos/x86_64/AlmaLinux-8.10-x86_64-dvd.iso
