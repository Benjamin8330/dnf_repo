rm -rf /444/output
# lorax -p "My Alma" -v "8.10" -r "1" -s file:///444/2/BaseOS -s file:///444/2/AppStream --nomacboot ./output
lorax -p "My_Alma" -v "8.10" -r "1" -s file:///444/2 --nomacboot /444/output
