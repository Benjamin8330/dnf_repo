rm -rf ./output
# lorax -p "My Alma" -v "8.10" -r "1" -s file:///444/2/BaseOS -s file:///444/2/AppStream --nomacboot ./output
 lorax -p "My Alma" -v "8.10" -r "1" -s file:///444/2 --nomacboot ./output
